/**
 * 
 */
/**
 * 
 */
module NinjasOOP {
}